/**
 * @file lib.c
 * @brief 
 * @author Airead Fan <fgh1987168@gmail.com>
 * @date 2012/12/03 09:36:57
 */

#include <stdio.h>

void lib_print(char *str)
{
    printf("%s", str);
}