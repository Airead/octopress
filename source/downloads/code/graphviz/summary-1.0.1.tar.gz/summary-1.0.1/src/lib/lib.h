#ifndef _LIB_H_
#define _LIB_H_

void lib_print(char *str);

#endif /* _LIB_H_ */
